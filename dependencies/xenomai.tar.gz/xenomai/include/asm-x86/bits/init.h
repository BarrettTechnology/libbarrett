#ifdef __i386__
#include "init_32.h"
#else
#include "init_64.h"
#endif

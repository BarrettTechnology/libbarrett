#ifdef __i386__
#include "thread_32.h"
#else
#include "thread_64.h"
#endif

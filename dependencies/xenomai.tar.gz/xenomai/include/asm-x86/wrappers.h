#ifdef __i386__
#include "wrappers_32.h"
#else
#include "wrappers_64.h"
#endif

#ifdef __i386__
#include "atomic_32.h"
#else
#include "atomic_64.h"
#endif

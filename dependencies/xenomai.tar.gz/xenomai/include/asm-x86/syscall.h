#ifdef __i386__
#include "syscall_32.h"
#else
#include "syscall_64.h"
#endif

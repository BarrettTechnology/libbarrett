#ifndef _XENO_ASM_ARM_ARITH_H
#define _XENO_ASM_ARM_ARITH_H

#include <asm-generic/xenomai/arith.h>

#endif /* _XENO_ASM_ARM_ARITH_H */
